<?php include("inc_header.php");
if (!in_array("siswa", $_SESSION['admin_akses'])) {
    echo "kamu tidak memiliki akses";
    include("inc_footer.php");
    exit();
}
?>
<?php include("inc_footer.php");
require 'functions.php';
$result = mysqli_query($conn, "SELECT * FROM mahasiswa");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            background: #dedede;
            margin: 0;
            padding: 0;
        }

        h1 {
            text-align: center;
            color: black;
        }

        th {
            color: white;
            background: blue;
        }

        tr {
            margin: auto;
            text-align: center;
            align-items: center;
        }

        td {
            color: black;
            background: white;
        }

        table {
            margin: auto;
        }

        #btn-2 {
            padding: 10px 25px;
            background: blue;
            border: transparent;
            border-radius: 5px;
            margin: auto;
            display: flex;
            margin-top: 30px;
            box-shadow: 0 0 10px rgba(1, 1, 1, 0.8);
        }

        #btn-2:hover {
            background: #333;
            transform: scale(1.03);
        }

        a {
            color: white;
            text-decoration: none;
            text-align: center;
            margin: auto;
        }

        .footer {
            clear: both;
            text-align: center;
            padding: 20px;
            background-color: #3498db;
            color: #fff;
        }
    </style>
</head>

<body>
    <diiv>
        <h1>DATA BUKU</h1>
        <table border="1" cellpadding="10" cellspacing="0">

            <tr>
                <th>ID</th>
                <th>JENIS BUKU</th>
                <th>MK</th>
                <th>DOSEN</th>
                <th>UNIVERSITAS</th>
                <th>GAMBAR</th>
            </tr>

            <?php $i = 1; ?>
            <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                <tr>
                    <td><?= $i; ?> </td>
                    <td><?= $row["nama"]; ?></td>
                    <td><?= $row["email"]; ?></td>
                    <td><?= $row["jurusan"]; ?></td>
                    <td><?= $row["universitas"]; ?></td>
                    <td><img src="img/<?php echo $row["gambar"]; ?>" width="50"></td>
                </tr>
                <?php $i++; ?>
            <?php endwhile; ?>

        </table>
    </diiv>
</body>

</html>