<?php include("inc_header.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Mata Kuliah Page</title>
    <style>
body {
    margin: 0;
    padding: 0;
}

header {
    background-color: #4CAF50;
    color: white;
    text-align: center;
    padding: 1em;
}

section {
    padding: 20px;
}

    </style>
</head>
<body>
    <header>
        <h1>Mata Kuliah</h1>
        <p>Selamat datang di halaman mata kuliah kami.</p>
    </header>
    
    <section id="matakuliah1">
        <h2>Mata Kuliah 1</h2>
        <p>Deskripsi singkat mengenai mata kuliah 1.</p>
    </section>
    
    <section id="matakuliah2">
        <h2>Mata Kuliah 2</h2>
        <p>Deskripsi singkat mengenai mata kuliah 2.</p>
    </section>
    
    <section id="matakuliah3">
        <h2>Mata Kuliah 3</h2>
        <p>Deskripsi singkat mengenai mata kuliah 3.</p>
    </section>
    
</body>
</html>
