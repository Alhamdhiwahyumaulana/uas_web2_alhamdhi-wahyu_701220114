<?php
require 'functions.php';

if (isset($_POST["submit"])) {

    if (tambah($_POST) > 0) {
        echo "
            <script>
            alert('data berhasil ditambahkan!');
            document.location.href = 'admin_siswa.php';
            </script>        
        ";
    } else {
        echo "
            <script>
            alert('data gagal ditambahkan!');
            document.location.href = 'admin_siswa.php';
            </script>        
        ";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }

        .wrapper {
            max-width: 500px;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .input-box {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        .teks1 {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .btn-warning {
            position: relative;
            overflow: hidden;
            color: #fff;
            background-color: blue;
            border-color: #eea236;
            padding: 5px 8px;
            font-size: 14px;
            text-align: center;
            text-decoration: none;
            cursor: pointer;
            border: 1px solid transparent;
            border-radius: 4px;
            margin: auto;
            display: block;
        }

        #gambar {
            display: none;
        }

        .btn-warning label {
            display: block;
            padding: 6px 12px;
            margin-bottom: 0;
            font-size: 14px;
            line-height: 1.42857143;
            color: #333;
            white-space: nowrap;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        #btn-1 {
            background-color: red;
            color: #fff;
            padding: 10px 100px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin: auto;
            display: block;
        }

        #btn-1:hover {
            background-color: #31b0d5;
        }
    </style>
</head>

<body>
    <div>
        <h1>DAFTAR MATAKULIAH</h1>
        <div class="wrapper">
            <form action="" method="post" enctype="multipart/form-data">
                <div class="input-box">
                    <label for="nama"><b>JENIS BUKU : </b></label>
                    <input class="teks1" type="text" name="nama" id="nama" required>
                </div>
                <div>
                    <div class="input-box">
                        <label for="email"><b>MK : </b></label>
                        <input class="teks1" type="text" name="email" id="email" required>
                    </div>
                    <div>
                        <div class="input-box">
                            <label for="jurusan"><b>DOSEN : </b></label>
                            <input class="teks1" type="text" name="jurusan" id="jurusan" required>
                        </div>
                        <div>
                            <div class="input-box">
                                <label for="universitas"><b>UNIVERSITAS : </b></label>
                                <input class="teks1" type="text" name="universitas" id="universitas" required>
                            </div>
                            <div>
                                <div class="btn-warning">
                                    <label for="gambar">
                                    </label>
                                    <input type="file" name="gambar" id="gambar" required>
                                    Pilih File
                                    </input>
                                </div>
                                <br>
                                <div>
                                    <button id="btn-1" type="submit" name="submit"><b>Tambah</b></button>
                                </div>
            </form>
        </div>

</body>

</html>